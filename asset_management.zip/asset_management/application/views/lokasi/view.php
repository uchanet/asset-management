<button type="button" class="btn btn-primary">Input Data</button> <br>

<div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Table Lokasi</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Lokasi</th>
                  <th>Aksi</th>
                  
                </tr>
                </thead>
                <tbody>
                <?php 
                $no =1;
                foreach ($data_lokasi as $row)
                {
                    ?>
                
                <tr>
                <td width='3%'><?php echo $no++ ?></td>
             
                <td><?php echo $row->nama_lokasi; ?></td>
                
                <td>
                <button type="button" class="btn btn-success btn-xs"><i class="fa fa-edit"></i>Edit</button>
                <button type="button" class="btn btn-danger btn-xs">Hapus</button>
                </td></tr>
                <?php } 
                ?>
                </tbody>
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->


<!-- jQuery 3 -->
<script src="<?php echo base_url('asset/admin/'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url('asset/admin/'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('asset/admin/'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script>
$(function() {
    $('#example1').DataTable()
})
</script>