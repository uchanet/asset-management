<div class="col-md-12">
	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">Input Data Jabatan</h3>
		</div>
		<form method="POST" action="<?php echo base_url('index.php/barang/simpan'); ?>" class="form-horizontal">
			<div class="box-body">

			<div class="form-group">
					<label class="col-sm-2 control-label">Nama Jabatan</label>
					<div class="col-sm-5">
						<input type="text" name="jabatan" id="jabatan" class="form-control" placeholder="Jabatan">
					</div>
				</div>
				
      <div class="box-footer">
				<a href="<?php echo base_url('index.php/jabatan'); ?>" class="btn btn-danger">Cancel</a>
				<button type="submit" class="btn btn-primary pull-right">Simpan</button>
			</div>
		</form>
	</div>
</div>
<!-- Select2 -->
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<script>
$(function(){
  $('#select2').select();
})
</script>