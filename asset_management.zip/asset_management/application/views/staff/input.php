<div class="col-md-12"> <!-- col digunakan untuk mengatur lebar layar terdiri dari 12 colom -->
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Input Data Staff</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <table  width='50%'>
           
              <tr>
                  <td>Nama Anda</td>
                  <td><form method="POST" action="<?php echo base_url ('index.php/staff/simpan'); ?>" class="form-horizontal">
              <div class="box-body">
              <input type="text" name="nama" id="nama" placeholder="Masukan Nama"></td>
              </tr>
              <tr>
                 <td>Jabatan Anda</td>
                 <td><select id="jabatan_id" name="jabatan_id">
              <option>Pilih Jabatan</option>
              <?php foreach ($jabatan as $j)
              {
                  ?>
                  <option value="<?php echo $j->id_jabatan; ?>"> <?php echo $j->nama; ?></option>
              }
            <?php } ?>
              </select></td>
              </tr>
              <tr>
                  <td>Lokasi</td>
                  <td><select id="lokasi_id" name="lokasi_id">
              <option>Pilih Lokasi</option>
              <?php foreach ($lokasi as $j)
              {
                  ?>
                  <option value="<?php echo $j->id; ?>"> <?php echo $j->nama_lokasi; ?></option>
              }
            <?php } ?>
              </select></td>

              </tr>
      
            
            </table>
            
              <!-- /.box-body -->
              <div class="box-footer">
                <button <?php echo base_url('index.php/staff');?> class="btn btn-default">Batal</button>
                <button type="submit" class="btn btn-info pull-right">Simpan</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>