<a href="<?php echo base_url('index.php/asset/input'); ?>" class="btn btn-primary" style="margin-bottom:15px;"> Input Data</a>

<div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Asset</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th>No Asset</th>
                  <th >Nama Barang</th>
                  <th >Kondisi</th>
                  <th>Nama Staff</th>
                  <th >Staff ID</th>
                  <th>Jabatan</th>
                  <th>Lokasi</th>
                  <th>tanggal</th>
                  <th > Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  $no = 1; 
                foreach($data_asset as $row)
                     { 
                      ?>
                <tr>
                  <td><?php echo $no++ ?></td>
                  <td><?php echo $row->no_asset; ?></td>
                  <td><?php echo $row->barang; ?></td>
                  <td><?php echo $row->kondisi; ?></td>
                  <td><?php echo $row->staff; ?></td>
                  <td><?php echo $row->staf_id; ?></td>
                  <td><?php echo $row->jabatan; ?></td>
                  <td><?php echo $row->lokasi; ?></td>
                  <td><?php echo $row->tanggal; ?></td>
                  <td>
                    <a href="<?php echo base_url ('index.php/asset/update/' .$row->id); ?>" class="btn btn-success btn-xs"><i class="fa fa-edit"></i>Edit</a>
                    <a href="<?php echo base_url ('index.php/asset/hapus/' .$row->id); ?>" class="btn btn-danger btn-xs"><i class="fa fa-edit"></i>Hapus</a>
                    
                  </td>
                 </tr>
                 
                 <?php    } ?>
            
                
                </tbody>
                 
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->


<!-- jQuery 3 -->
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script>
  $(function() {
    $('#example1').DataTable()
   
  })
</script>