<div class="col-md-12">
	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">Input Data Asset</h3>
		</div>
		<form method="POST" action="<?php echo base_url('index.php/asset/simpan'); ?>" class="form-horizontal">
			<div class="box-body">

			<div class="form-group">
                    <label class="col-sm-2 control-label">Nama Barang</label>
                    <div class="col-sm-5">
                        <select id="barang_id" name="barang_id" style="width:100%;" class="form-control" >
                            <option>Pilih Barang</option>
                            <?php foreach ($data_barang as $j)              
                { ?>
                            <option value="<?php echo $j->id; ?>" <?php if (isset ($data_asset))
                            {
                                if ($data_asset->barang_id == $j->id)
                                {
                                    echo 'selected';
                                }
                            } ?> > <?php echo $j->nama; ?>

                            <option value="<?php echo $j->id; ?>"> <?php echo $j->nama; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Nama Staff</label>
                    <div class="col-sm-5">
                        <select id="staff_id" name="staff_id" style="width:100%;" class="form-control">
                            <option>Pilih Staff</option>
                            <?php foreach ($data_staff as $j)
                { ?>
                            <option value="<?php echo $j->id; ?>"  <?php if (isset ($data_asset))
                            {
                                if ($data_asset->staf_id == $j->id)
                                {
                                    echo 'selected';
                                }
                            } ?> > <?php echo $j->nama_staff; ?> | <?php echo $j->jabatan; ?> | <?php echo $j->lokasi; ?></option>
                            <?php } ?> 
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label">Kondisi</label>
                    <div class="col-sm-5">
                         <input type="text" class="form-control" name="kondisi" id="kondisi" value="<?php isset ($data_asset) ? print ($data_asset->kondisi) : '' ?>">
                    </div>
                </div>
            </div>

			<div class="form-group">
                    <label class="col-sm-2 control-label">Pilih Tanggal</label>
                    <div class="col-sm-5">
                    <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" name="tanggal" id="datepicker">
                </div>	    
                    </div>
                </div>
			

      <div class="box-footer">
                <a href="<?php echo base_url('index.php/asset'); ?>" class="btn btn-danger">Cancel</a>
                <button type="submit" class="btn btn-primary pull-right">Simpan</button>
            </div>
            <input type="hidden" name="id" value="<?php isset($data_asset) ? print ($data_asset->id) : '' ?> "/>
        </form>
    </div>
</div>

<!-- Select2 -->
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>

<script>
$(function(){
  $('#select2').select();
  $('#datepicker').datepicker(
  {
	autoclose : true
  });
})
</script>



