<div class="col-md-12">
	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">Input Data Barang</h3>
		</div>
		<form method="POST" action="<?php echo base_url('index.php/barang/simpan'); ?>" class="form-horizontal">
			<div class="box-body">

			<div class="form-group">
					<label class="col-sm-2 control-label">No Aset</label>
					<div class="col-sm-5">
						<input type="text" name="no_aset" id="no_aset" class="form-control" placeholder="No Aset">
					</div>
				</div>


				<div class="form-group">
					<label class="col-sm-2 control-label">Nama Barang</label>
					<div class="col-sm-5">
						<input type="text" name="nama" id="nama" class="form-control" placeholder="Nama Barang">
					</div>
				</div>

				<div class="form-group">
					<label class="col-sm-2 control-label">Tipe</label>
					<div class="col-sm-5">
						<input type="text" name="tipe" id="tipe" class="form-control" placeholder="Tipe">
					</div>
				</div>

				<div class="form-group">
					<label class="col-sm-2 control-label">Merek</label>
					<div class="col-sm-5">
						<input type="text" name="merek" id="merek" class="form-control" placeholder="Merek">
					</div>
				</div>



				<div class="form-group">
					<label class="col-sm-2 control-label">Kategori</label>
					<div class="col-sm-5">
						<select id="kategori_id" name="kategori_id" style="width:100%;" class="form-control">
							<option>Pilih Kategori</option>
							<?php foreach ($data_kategori as $j)
                { ?>
							<option value="<?php echo $j->id; ?>"> <?php echo $j->nama_kategori; ?></option>
							<?php } ?>
						</select>
					</div>
				</div>
			</div>

      <div class="box-footer">
				<a href="<?php echo base_url('index.php/barang'); ?>" class="btn btn-danger">Cancel</a>
				<button type="submit" class="btn btn-primary pull-right">Simpan</button>
			</div>
		</form>
	</div>
</div>
<!-- Select2 -->
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
<script>
$(function(){
  $('#select2').select();
})
</script>