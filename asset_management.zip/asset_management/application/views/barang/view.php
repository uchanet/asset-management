<a href="<?php echo base_url('index.php/barang/input'); ?>" class="btn btn-primary" style="margin-bottom:15px;"> Input Data</a>

<div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Aset</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="5%">No</th>
                  <th>No Asset</th>
                  <th >Nama Barang</th>
                  <th >Tipe</th>
                  <th >Merek</th>
                  <th >Kategori</th>
                  <th > Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php
                  $no = 1; 
                foreach($data_barang as $row)
                     { 
                      ?>
                <tr>
                  <td><?php echo $no++ ?></td>
                  <td><?php echo $row->no_asset; ?></td>
                  <td><?php echo $row->nama; ?></td>
                  <td><?php echo $row->tipe; ?></td>
                  <td><?php echo $row->merek; ?></td>
                  <td><?php echo $row->kategori_id; ?></td>
                  <td>
                    <button type="button" class="btn btn-success btn-xs"><i class="fa fa-edit"></i>Edit</button>
                    <button type="button" class="btn btn-danger btn-xs">Hapus</button>
                  </td>
                 </tr>
                 
                 <?php    } ?>
            
                
                </tbody>
                 
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->


<!-- jQuery 3 -->
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('asset/admin-lte/'); ?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script>
  $(function() {
    $('#example1').DataTable()
   
  })
</script>