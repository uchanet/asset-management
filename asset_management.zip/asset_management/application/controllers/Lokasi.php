<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lokasi extends CI_Controller {

	public function index()
	{
		$this->load->model('LokasiModel');
		$lokasi = $this->LokasiModel->getData();
		// cara mengecek data base
		// print_r ($jabatan);
	$data['content']='lokasi/view';
	$data['data_lokasi']= $lokasi;
	$this->load->view('template/master', $data);
	}
}
