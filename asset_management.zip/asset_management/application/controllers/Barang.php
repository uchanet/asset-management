<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {

	public function index()
	{
		$this->load->model('BarangModel');
		$barang = $this->BarangModel->getData();
		// cara mengecek data base
		// print_r ($jabatan);
	$data['content']='barang/view';
	$data['data_barang']= $barang;
	$this->load->view('template/master', $data);
	}
	
	public function input()
	{
		$this->load->model('BarangModel');
		$data['data_kategori'] =  $this->BarangModel->getKategori();
		$data['content'] = 'barang/input';
		$this->load->view('template/master', $data);


	}

	public function simpan()
	{
		$this->load->model('BarangModel');
		
		$isi  = [
			'no_asset' => $this->input->post('no_aset'),
			'nama' => $this->input->post('nama'),
			'tipe' => $this->input->post('tipe'),
			'merek' => $this->input->post('merek'),
			'kategori_id' => $this->input->post('kategori_id'),
		];
		$this->BarangModel->simpan($isi);
		$this->index();

	}
}
