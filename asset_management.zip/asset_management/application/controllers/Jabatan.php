<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jabatan extends CI_Controller {

	public function index()
	{
		$this->load->model('JabatanModel');
		$jabatan = $this->JabatanModel->getData();
		// cara mengecek data base
		// print_r ($jabatan);
		
	$data['content']='jabatan/view';
	$data['data_jabatan']= $jabatan;
	$this->load->view('template/master', $data);
	}
}
