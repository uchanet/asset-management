<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Asset extends CI_Controller {
 
	public function index()
	{
		$this->load->model('AssetModel');
		$data['data_asset'] =  $this->AssetModel->getData();
		$data['content'] = 'asset/view';
		$this->load->view('template/master', $data);
	}

	public function input()
	{
		$this->load->model('AssetModel');
		$data['data_staff'] =  $this->AssetModel->getStaff();
		$data['data_barang'] =  $this->AssetModel->getBarang();
		$data['content'] = 'asset/input';
		$this->load->view('template/master', $data);


	}

	public function simpan()
	{
		$this->load->model('AssetModel');
		$id = $this->input->post('id');
		$isi  = [
			//'no_asset' => $this->input->post('no_aset'),
			'barang_id' => $this->input->post('barang_id'),
			'staf_id' => $this->input->post('staff_id'),
			'kondisi' => $this->input->post('kondisi'),
			'tanggal' => date("Y-m-d", strtotime($this->input->post('tanggal'))),
		];
		if ($id > 0)
		{
			$this->AssetModel->update($id, $isi);
		}else {
			$this->AssetModel->simpan($isi);
		}
		redirect('asset');

	}
	public function update ($id=0)
	{
		if ($id > 0)
		{
		//Jalankan Perintah mencari data yang akan di edit
		
		$this->load->model('AssetModel');
		$result = $this->AssetModel->get_data_by_id($id);
		//$data['no_asset'] = $this->AssetModel->getAsset();	
		$data['data_staff'] =  $this->AssetModel->getStaff();
		$data['data_barang'] =  $this->AssetModel->getBarang();
		$data['data_asset'] = $result;
		$data['content'] = 'asset/input';
		$this->load->view('template/master', $data);
	
		}
	}
	public function hapus($id)
	{
		if ($id > 0)
		{
			$isi = [
				'status' => 0
			];
			$this->load->model('AssetModel');
			$this->AssetModel->update($id, $isi);
			redirect('asset');
		}
	}
	
 
}