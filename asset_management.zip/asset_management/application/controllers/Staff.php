<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Staff extends CI_Controller {

	public function index()
	{
		$this->load->model('StaffModel');
		$staff = $this->StaffModel->getData();
		// cara mengecek data base
		// print_r ($jabatan);
	$data['content']='staff/view';
	$data['data_staff']= $staff;
	$this->load->view('template/master', $data);
	}
	public function input ()
	{
		$this->load->model('StaffModel');
		$data['jabatan']= $this->StaffModel->getJabatan();
		$data['lokasi']= $this->StaffModel->getLokasi();

		$data['content']='staff/input';
		$this->load->view('template/master', $data);
	}
	public function simpan()
	{
		$this->load->model('StaffModel');
		$simpan = [
			'nama_staff' => $this->input->post('nama'),
			'jabatan_id' => $this->input->post('jabatan_id'),
			'lokasi_id'=> $this->input->post('lokasi_id')
		];
		$this->StaffModel->simpan($simpan);
		$this->index();
		
	}
}