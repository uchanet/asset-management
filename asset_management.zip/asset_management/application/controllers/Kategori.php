<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller {

	public function index()
	{
		$this->load->model('KategoriModel');
		$kategori = $this->KategoriModel->getData();
		// cara mengecek data base
		// print_r ($jabatan);
		
	$data['content']='kategori/view';
	$data['data_kategori']= $kategori;
	$this->load->view('template/master', $data);
	}
}
