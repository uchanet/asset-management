<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model {
      function cekuser ($e,$p) {
          return $this->db->where ('email', $e)
                        ->where ('password', $p)
                        ->get('user')
                        ->row();
      }
      function cekEmail ($email){
          return $this->db->where ('email', $e)
          ->where ('password', $p)
          ->get('user')
          ->row();
          
      }
      function cekPassword ($email, $password){
          return $this->db->where ('email', $email)
                        ->where('password', $password)
                        ->get('user')
                        ->row();
      }
}