<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StaffModel extends CI_Model {
    function getdata (){
      //return  $this->db->get('staff')->result();
      
      return $this->db->select('staff.id, staff.nama_staff, jabatan.nama as jabatan, lokasi.nama_lokasi as lokasi')
      ->join('jabatan','jabatan.id_jabatan= staff.jabatan_id')
      ->join ('lokasi','lokasi.id = staff.lokasi_id')
      ->get('staff')->result();



//       SELECT staff.id, staff.nama_staff, jabatan.nama as 'jabatan',
// lokasi.nama_lokasi as 'lokasi' FROM staff
// left join jabatan on jabatan.id_jabatan= staff.jabatan_id
// left join lokasi on lokasi.id = staff.lokasi_id
//return $this->db->query($data)->
    }
    function getJabatan (){
    return $this->db->get('jabatan') 
    ->result();
    }

    function getLokasi (){
      return $this->db->get('lokasi') 
      ->result();
      }
    function simpan($data)
    {
      $this->db->insert('staff', $data);
    }
}