<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AssetModel extends CI_Model{

function getdata()
{
  return $this->db->select('asset.*, barang.no_asset, barang.nama as barang,
                            kategori.nama_kategori as kategori, staff.nama_staff as staff,
                            jabatan.nama as jabatan, lokasi.nama_lokasi as lokasi')
                            
                    ->join('barang','barang.id = asset.barang_id','left')
                    ->join('kategori','kategori.id = barang.kategori_id','left')
                    ->join('staff','staff.id = asset.staf_id','left')
                    ->join('lokasi','lokasi.id =  staff.lokasi_id','left')
                    ->join('jabatan','jabatan.id_jabatan = staff.jabatan_id','left')
                    ->where ('asset.status', 1)
                    ->get('asset')->result();

}

 function getBarang()
 {
     return $this->db->get('barang')->result();
 }
 function getStaff()
 {
    return $this->db->select('staff.*, jabatan.nama as jabatan, lokasi.nama_lokasi as lokasi')
    ->join('lokasi','lokasi.id =  staff.lokasi_id','left')
    
     ->join('jabatan','jabatan.id_jabatan = staff.jabatan_id','left')
     ->get('staff')->result();

 }

 function simpan($data)
 {
     $this->db->insert('asset',$data);
 }
 function update ($id, $isi)
 {
     $this->db->where('id', $id)->update ('asset', $isi);
 }
function get_data_by_id ($id)
{
    //$caridata = "select * from asset where id = $id;
    return $this->db->where('id', $id)->get('asset')->row();
}
}