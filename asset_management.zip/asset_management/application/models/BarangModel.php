<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BarangModel extends CI_Model {
      function getdata()
                      {
                          return $this->db->select('barang.*, kategori.nama_kategori as kategori')
                                      ->join('kategori','kategori.id = barang.kategori_id','left')            
                                      ->get('barang')->result();
                      
                      }
                      
                      function getKategori()
                      {
                          return $this->db->get('kategori')->result();
                      }
                      function simpan($data){
                          $this->db->insert('barang', $data);
                      }
}