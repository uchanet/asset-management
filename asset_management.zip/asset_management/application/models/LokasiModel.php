<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LokasiModel extends CI_Model {
    function getdata (){
      return  $this->db->get('lokasi')->result();
      
    
    }
}