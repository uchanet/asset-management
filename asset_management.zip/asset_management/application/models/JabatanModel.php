<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class JabatanModel extends CI_Model {
    function getdata (){
      return  $this->db->get('jabatan')->result();
      
    
    }
}