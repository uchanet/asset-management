<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class KategoriModel extends CI_Model {
    function getdata (){
      return  $this->db->get('kategori')->result();
      
    
    }
}