<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HomeModel extends CI_Model{
  function menghitung_jumlah_staff()
  {
     return $this->db->count_all('staff');
  }
  function menghitung_jumlah_jabatan()
  {
     return $this->db->count_all('jabatan');
  }
}